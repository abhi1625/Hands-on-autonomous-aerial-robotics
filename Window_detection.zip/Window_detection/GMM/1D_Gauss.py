import os

print("Detecting green buoys with 1D-Gaussian")
os.system("python 1D_gauss_green.py")
print("Detecting yellow buoys with 1D-Gaussian")
os.system("python 1D_gauss_yellow.py")
print("Detecting orange buoys with 1D-Gaussian")
os.system("python 1D_gauss_orange.py")

