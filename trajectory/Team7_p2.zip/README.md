# Run instructions
to execute the file use
```
python traj_gen.py
```